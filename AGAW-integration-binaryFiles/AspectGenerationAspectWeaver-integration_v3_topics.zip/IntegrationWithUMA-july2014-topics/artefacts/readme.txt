Changes:

- New versions of the modules include themself the other artefacts required. 
- External dependencies are not included in the artefacts.
- The modules run in their own thread.


14 july
- topics instead of queues in the ActiveMQ. Properties files does not change.
